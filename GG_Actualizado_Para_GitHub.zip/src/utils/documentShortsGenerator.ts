import { BookCollection, ReelShort, VisualTheme, VideoScene, QuizData } from '../types';

// Palette of themes for varied reel presentations
const VISUAL_THEMES: VisualTheme[] = ['amber', 'gold', 'emerald', 'cyan', 'violet', 'indigo', 'rose'];

// Emojis for reel lesson titles
const LESSON_EMOJIS = ['💡', '⚡', '🧠', '🎯', '🔥', '💎', '🚀', '📖', '🌟', '🛡️', '🔑', '🏆', '📈', '🧘', '💰'];

// Preset hook templates depending on selected tone
const TONE_HOOKS: Record<string, string[]> = {
  viral: [
    'Si ganas dinero o trabajas duro y no aplicas esto hoy, estás trabajando como esclavo de todos menos de ti mismo.',
    'El 95% de las personas comete este error a diario pensando que es lo normal.',
    'No necesitas más tiempo, necesitas entender esta sola regla que la mayoría ignora.',
    'La diferencia entre los que logran sus metas y los que se quedan a medias se reduce a este principio.',
    'Guarda este reel porque lo que estás a punto de escuchar te ahorrará 5 años de tropiezos.',
    'Si estás postergando lo importante, tu cerebro te está engañando con esta trampa invisible.',
    'Lo que nadie te dijo sobre el éxito es que no empieza con motivación, empieza con esto.',
  ],
  storytelling: [
    'Hace años un sabio maestro compartió una verdad que transformó para siempre la vida de quienes la escucharon.',
    'Cuenta la historia que las personas más prósperas de la antigüedad tenían un secreto inquebrantable.',
    'Cuando todo parecía indicar que el camino era imposible, este simple cambio de perspectiva lo cambió todo.',
    'Imagina levantarte cada mañana sabiendo exactamente qué paso dar sin dudar ni un segundo.',
    'Un error de cálculo casi arruinó su destino, hasta que descubrió la regla que hoy vas a aprender.',
  ],
  class: [
    'En los próximos 40 segundos vas a dominar el concepto fundamental que divide a los profesionales de los aficionados.',
    'Bienvenido a tu micro-lección de hoy: un marco mental comprobado para tomar mejores decisiones.',
    'Desglosemos en 3 puntos claros cómo ejecutar esta estrategia de forma simple y efectiva.',
    'La evidencia es clara: quienes dominan esta técnica multiplican su enfoque y retención.',
  ],
  mindset: [
    'Tu mente busca la comodidad, pero tu grandeza está justo del otro lado de esta pequeña incomodidad.',
    'No atraes lo que deseas, atraes lo que eres capaz de sostener con tus hábitos diarios.',
    'Cada decisión de hoy es un voto por la persona en la que te vas a convertir mañana.',
    'El verdadero dominio personal no es controlar a los demás, es tener el control total sobre tus reacciones.',
  ],
};

/**
 * Extracts plain text from diverse file types in pure client-side JavaScript.
 */
export async function extractTextFromFile(file: File): Promise<string> {
  const fileName = file.name.toLowerCase();

  // 1. Plain text, markdown, JSON, CSV
  if (
    fileName.endsWith('.txt') ||
    fileName.endsWith('.md') ||
    fileName.endsWith('.json') ||
    fileName.endsWith('.csv') ||
    file.type.startsWith('text/')
  ) {
    return await file.text();
  }

  // 2. PDF extraction via stream parsing
  if (fileName.endsWith('.pdf') || file.type === 'application/pdf') {
    try {
      const buffer = await file.arrayBuffer();
      const bytes = new Uint8Array(buffer);
      let text = '';

      // Search for text chunks in PDF stream objects
      const decoder = new TextDecoder('utf-8', { fatal: false });
      const rawStr = decoder.decode(bytes);

      // Match text within parentheses in Tj and TJ operators
      const tjMatches = rawStr.matchAll(/\(([^)]+)\)\s*Tj/g);
      for (const m of tjMatches) {
        if (m[1] && m[1].length > 2) {
          text += m[1] + ' ';
        }
      }

      // Also match TJ array strings
      const arrayMatches = rawStr.matchAll(/\[(.*?)\]\s*TJ/g);
      for (const m of arrayMatches) {
        const inner = m[1];
        const innerMatches = inner.matchAll(/\(([^)]+)\)/g);
        for (const im of innerMatches) {
          if (im[1] && im[1].length > 2) {
            text += im[1] + ' ';
          }
        }
      }

      // If text stream operators found, clean and return
      if (text.trim().length > 100) {
        return cleanExtractedText(text);
      }

      // Fallback: extract ASCII readable string blocks
      const asciiBlocks = rawStr.match(/[A-Za-zÀ-ÿ0-9\s,.\-—–:;?!¿¡'"%$()]{10,}/g);
      if (asciiBlocks && asciiBlocks.length > 5) {
        return cleanExtractedText(asciiBlocks.join('\n'));
      }
    } catch (e) {
      console.warn('PDF stream extraction fallback:', e);
    }
  }

  // 3. DOCX extraction (search for <w:t> XML text nodes in binary)
  if (fileName.endsWith('.docx') || fileName.endsWith('.doc')) {
    try {
      const buffer = await file.arrayBuffer();
      const rawStr = new TextDecoder('utf-8', { fatal: false }).decode(new Uint8Array(buffer));
      const wtMatches = rawStr.matchAll(/<w:t[^>]*>([^<]+)<\/w:t>/g);
      let docxText = '';
      for (const m of wtMatches) {
        if (m[1]) docxText += m[1] + ' ';
      }
      if (docxText.trim().length > 50) {
        return cleanExtractedText(docxText);
      }
    } catch (e) {
      console.warn('DOCX extraction fallback:', e);
    }
  }

  // Default fallback: return file name as context
  return file.name.replace(/\.[^/.]+$/, '').replace(/[-_]/g, ' ');
}

function cleanExtractedText(raw: string): string {
  return raw
    .replace(/\\n/g, ' ')
    .replace(/\\r/g, ' ')
    .replace(/\\/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

/**
 * Splits extracted text into logical thematic chunks for reel generation.
 */
function extractThematicChunks(text: string, count: number): string[] {
  if (!text || text.length < 50) return [];

  // Split by paragraphs or sentence blocks
  const sentences = text
    .split(/(?<=[.?!])\s+/)
    .map((s) => s.trim())
    .filter((s) => s.length > 20);

  if (sentences.length === 0) return [];

  const chunkSize = Math.max(1, Math.floor(sentences.length / count));
  const chunks: string[] = [];

  for (let i = 0; i < count; i++) {
    const slice = sentences.slice(i * chunkSize, (i + 1) * chunkSize);
    if (slice.length > 0) {
      chunks.push(slice.join(' '));
    }
  }

  return chunks;
}

export interface GenerationParams {
  title: string;
  author?: string;
  text?: string;
  count: number;
  tone?: string;
  viralTrend?: string;
}

/**
 * Core client-side generation engine: converts document content into a full BookCollection of reels.
 * Guaranteed 100% offline-compatible and resilient.
 */
export function generateLocalCollection({
  title,
  author = 'Autor Destacado',
  text = '',
  count,
  tone = '⚡ Dinámico & Viral',
  viralTrend,
}: GenerationParams): BookCollection {
  const collectionId = `coll_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  const cleanTitle = title.trim() || 'Documento de Aprendizaje';
  const cleanAuthor = author.trim() || 'Sabiduría Aplicada';
  const reelCount = Math.max(1, Math.min(30, count));

  // Determine tone key
  let toneKey = 'viral';
  if (tone.includes('Storytelling')) toneKey = 'storytelling';
  else if (tone.includes('Micro-Clase')) toneKey = 'class';
  else if (tone.includes('Mindset')) toneKey = 'mindset';

  const toneHookPool = TONE_HOOKS[toneKey] || TONE_HOOKS.viral;
  const chunks = extractThematicChunks(text, reelCount);

  // Lesson concept archetypes
  const lessonArchetypes = [
    { title: 'La Regla de Oro', verb: 'Priorizar lo esencial antes de cualquier gasto o distracción' },
    { title: 'El Hábito Maestro', verb: 'Construir una rutina matutina invencible de 15 minutos' },
    { title: 'El Efecto Compuesto', verb: 'Multiplicar tus resultados con pequeñas mejoras del 1% cada día' },
    { title: 'La Ley del Enfoque', verb: 'Eliminar las 3 distracciones que devoran el 80% de tu energía' },
    { title: 'Dominio Emocional', verb: 'Mantener la calma y claridad estratégica bajo presión' },
    { title: 'Mentalidad Antifrágil', verb: 'Convertir cada obstáculo en combustible para tu crecimiento' },
    { title: 'La Trampa Invisible', verb: 'Detectar los sesgos que te hacen perder tiempo y dinero' },
    { title: 'Acción Inmediata', verb: 'Vencer la procrastinación con la regla de los 2 minutos' },
    { title: 'Sistemas sobre Metas', verb: 'Diseñar un entorno donde fallar sea casi imposible' },
    { title: 'El Salto Cuántico', verb: 'Tomar la decisión audaz que desbloquea tu siguiente nivel' },
    { title: 'Visión a Largo Plazo', verb: 'Sembrar hoy para cosechar libertad financiera y mental' },
    { title: 'Auditoría Personal', verb: 'Medir tus métricas clave cada noche antes de dormir' },
  ];

  const shorts: ReelShort[] = [];

  for (let i = 0; i < reelCount; i++) {
    const archetype = lessonArchetypes[i % lessonArchetypes.length];
    const emoji = LESSON_EMOJIS[i % LESSON_EMOJIS.length];
    const theme = VISUAL_THEMES[i % VISUAL_THEMES.length];
    const hookTemplate = toneHookPool[i % toneHookPool.length];
    const chunkText = chunks[i] || '';

    const lessonTitle = `${emoji} Lección #${i + 1}: ${archetype.title}`;

    // Extract genuine sentence or craft concept
    let coreInsight = '';
    if (chunkText.length > 40) {
      const firstSentence = chunkText.split(/[.?!]/)[0];
      coreInsight = `${firstSentence.trim()}. ${archetype.verb}.`;
    } else {
      coreInsight = `El principio fundamental consiste en ${archetype.verb.toLowerCase()}, garantizando progreso constante sin depender de la motivación momentánea.`;
    }

    // 3 Concrete Action Steps
    const steps = [
      `1. Identifica el obstáculo exacto que te impide ${archetype.verb.toLowerCase().slice(0, 35)}...`,
      `2. Implementa un disparador visual y ejecuta la primera acción en menos de 120 segundos.`,
      `3. Mide tu avance al finalizar la jornada y ajusta tu sistema para el día siguiente.`,
    ];

    // Actionable Takeaway
    const actionableTakeaway = `Configura un recordatorio hoy a las 6:00 PM y aplica esta lección durante al menos 10 minutos ininterrumpidos.`;

    // Quote
    const quote = chunkText.length > 50
      ? `"${chunkText.slice(0, 110)}..."`
      : `"La disciplina tarde o temprano superará a la inteligencia cuando la inteligencia no sea disciplinada."`;

    // Interactive Quiz
    const quiz: QuizData = {
      question: `¿Cuál es el beneficio directo de aplicar ${archetype.title.toLowerCase()} hoy?`,
      options: [
        `Garantizar progreso acumulativo y evitar la trampa de la procrastinación.`,
        `Esperar a tener motivación máxima antes de iniciar.`,
        `Depender exclusivamente de la fuerza de voluntad.`,
        `Hacer cambios drásticos e insostenibles de una sola vez.`,
      ],
      correctAnswerIndex: 0,
      explanation: `La clave del principio radica en ${archetype.verb.toLowerCase()}, creando inercia positiva sostenible.`,
    };

    // Storyboard Video Scenes
    const scenes: VideoScene[] = [
      {
        sceneNumber: 1,
        durationSec: 8,
        headline: archetype.title.toUpperCase(),
        subtext: 'Gancho inicial de alto impacto',
        visualPreset: 'gold-cascade',
        captionWords: hookTemplate.split(' ').slice(0, 10),
      },
      {
        sceneNumber: 2,
        durationSec: 14,
        headline: 'EL PRINCIPIO EN ACCIÓN',
        subtext: coreInsight.slice(0, 60),
        visualPreset: 'matrix-wealth',
        captionWords: coreInsight.split(' ').slice(0, 12),
      },
      {
        sceneNumber: 3,
        durationSec: 10,
        headline: 'APLICA ESTO HOY',
        subtext: actionableTakeaway.slice(0, 60),
        visualPreset: 'cyber-bars',
        captionWords: actionableTakeaway.split(' ').slice(0, 10),
      },
    ];

    const shortId = `short_${collectionId}_${i + 1}`;

    shorts.push({
      id: shortId,
      title: lessonTitle,
      bookTitle: cleanTitle,
      author: cleanAuthor,
      category: 'Sabiduría Práctica',
      readTime: '40s',
      hook: viralTrend ? `[${viralTrend}] ${hookTemplate}` : hookTemplate,
      coreInsight,
      steps,
      actionableTakeaway,
      quote,
      visualTheme: theme,
      keyPhrases: [
        archetype.title,
        coreInsight.slice(0, 60),
        actionableTakeaway.slice(0, 60),
      ],
      fullNarration: `${hookTemplate} ${coreInsight} Primero: ${steps[0]} Segundo: ${steps[1]} Tercero: ${steps[2]} Tu reto de hoy: ${actionableTakeaway}`,
      quiz,
      likes: Math.floor(1000 + Math.random() * 800),
      viralFormat: viralTrend || 'POV Estratégico',
      trendSource: 'GG ✝ Formatos Educativos',
      scenes,
    });
  }

  return {
    id: collectionId,
    title: cleanTitle,
    author: cleanAuthor,
    category: 'Documentos & Libros',
    summary: `Colección de ${reelCount} lecciones generadas a partir de "${cleanTitle}".`,
    coverGradient: 'from-amber-600 via-orange-600 to-amber-900',
    shorts,
    trendInspiration: viralTrend || undefined,
  };
}
