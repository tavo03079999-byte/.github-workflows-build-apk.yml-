import React, { useState, useEffect } from 'react';
import {
  Flame,
  Clock,
  Target,
  Gift,
  Check,
  Sparkles,
  BookOpen,
  PlusCircle,
  ChevronRight,
  Zap
} from 'lucide-react';
import { BookCollection, ReelShort } from '../types';
import { soundManager } from '../utils/audioEffects';

interface HomeTabProps {
  collections: BookCollection[];
  onSelectCollection: (collectionId: string) => void;
  onOpenLibrary: () => void;
  onOpenUpload: () => void;
  onPlayReel: (short: ReelShort, collectionId: string) => void;
  quizPoints: number;
  onAddPoints?: (points: number) => void;
}

const STREAK_KEY = 'gg_user_streak_v2';
const LEARNING_TIME_KEY = 'gg_learning_time_v2';
const MISSIONS_KEY = 'gg_claimed_missions_v2';

function getTodayString(): string {
  const d = new Date();
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function getYesterdayString(): string {
  const d = new Date();
  d.setDate(d.getDate() - 1);
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

interface StreakData {
  count: number;
  lastDate: string;
  history: string[];
}

export const HomeTab: React.FC<HomeTabProps> = ({
  collections,
  onOpenLibrary,
  onOpenUpload,
  onAddPoints,
}) => {
  const todayStr = getTodayString();
  const yesterdayStr = getYesterdayString();

  // Streak state with real persistence & advancing logic
  const [streakData, setStreakData] = useState<StreakData>(() => {
    try {
      const raw = localStorage.getItem(STREAK_KEY);
      if (raw) {
        const parsed: StreakData = JSON.parse(raw);
        // Check if user missed more than 1 day
        if (parsed.lastDate && parsed.lastDate !== todayStr && parsed.lastDate !== yesterdayStr) {
          // Missed days: reset streak to 0, history remains
          return { count: 0, lastDate: '', history: parsed.history || [] };
        }
        return parsed;
      }
    } catch (e) {}
    // Brand new user: 1 day initial waiting for today's check-in
    return { count: 1, lastDate: '', history: [] };
  });

  const hasCheckedInToday = streakData.lastDate === todayStr;

  // Learning Time state
  const [goalMinutes, setGoalMinutes] = useState<number>(() => {
    try {
      const saved = localStorage.getItem(LEARNING_TIME_KEY);
      if (saved) return JSON.parse(saved).goal || 25;
    } catch (e) {}
    return 25;
  });

  const [learnedMinutes, setLearnedMinutes] = useState<number>(() => {
    try {
      const saved = localStorage.getItem(LEARNING_TIME_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.date === todayStr) return parsed.minutes || 18;
      }
    } catch (e) {}
    return 18;
  });

  // Missions claimed today
  const [claimedMissions, setClaimedMissions] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(MISSIONS_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.date === todayStr) return parsed.missions || [];
      }
    } catch (e) {}
    return [];
  });

  const [claimedChest, setClaimedChest] = useState(false);

  // Sync learning time to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(
        LEARNING_TIME_KEY,
        JSON.stringify({ date: todayStr, minutes: learnedMinutes, goal: goalMinutes })
      );
    } catch (e) {}
  }, [learnedMinutes, goalMinutes, todayStr]);

  // Sync claimed missions
  useEffect(() => {
    try {
      localStorage.setItem(
        MISSIONS_KEY,
        JSON.stringify({ date: todayStr, missions: claimedMissions })
      );
    } catch (e) {}
  }, [claimedMissions, todayStr]);

  // Calculations for Learning Time
  const progressPercent = Math.min(100, Math.round((learnedMinutes / goalMinutes) * 100));
  const remainingMinutes = Math.max(0, goalMinutes - learnedMinutes);

  // Handle Real Check-in (advances streak day by day)
  const handleCheckIn = () => {
    if (hasCheckedInToday) return;
    soundManager.playSuccessChime();

    const newCount =
      streakData.lastDate === yesterdayStr
        ? streakData.count + 1
        : streakData.count === 0
        ? 1
        : streakData.count;

    const newHistory = Array.from(new Set([...streakData.history, todayStr]));
    const updated: StreakData = {
      count: newCount,
      lastDate: todayStr,
      history: newHistory,
    };

    setStreakData(updated);
    try {
      localStorage.setItem(STREAK_KEY, JSON.stringify(updated));
    } catch (e) {}

    if (onAddPoints) onAddPoints(20);
  };

  // Handle +5 min Sprint
  const handleAddSprint = () => {
    soundManager.playPop();
    setLearnedMinutes((prev) => prev + 5);
    if (onAddPoints) onAddPoints(5);
  };

  // Handle Claim Mission
  const handleClaimMission = (missionId: string, xp: number) => {
    if (claimedMissions.includes(missionId)) return;
    soundManager.playSuccessChime();
    setClaimedMissions((prev) => [...prev, missionId]);
    if (onAddPoints) onAddPoints(xp);
  };

  // Handle Claim Chest
  const handleClaimChest = () => {
    if (claimedChest) return;
    soundManager.playSuccessChime();
    setClaimedChest(true);
    if (onAddPoints) onAddPoints(50);
  };

  // Real Weekly Track (Monday to Sunday)
  const now = new Date();
  const currentDayOfWeek = (now.getDay() + 6) % 7; // 0 = Lun, 1 = Mar, ..., 6 = Dom
  const weekDayLabels = ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'];

  const daysOfWeek = weekDayLabels.map((label, idx) => {
    const d = new Date(now);
    d.setDate(now.getDate() - currentDayOfWeek + idx);
    const dateKey = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    const isToday = idx === currentDayOfWeek;
    const isChecked = streakData.history.includes(dateKey) || (isToday && hasCheckedInToday);
    const isPast = idx < currentDayOfWeek;
    const isFuture = idx > currentDayOfWeek;

    return {
      label,
      isToday,
      isChecked,
      isPast,
      isFuture,
    };
  });

  // Calculate dynamic multiplier
  const multiplier =
    streakData.count >= 7
      ? 'x2.0'
      : streakData.count >= 5
      ? 'x1.5'
      : streakData.count >= 3
      ? 'x1.3'
      : 'x1.1';

  return (
    <div className="w-full max-w-2xl mx-auto px-4 pt-4 pb-28 text-white animate-fade-in space-y-4">
      {/* Brand Header with Orange Logo */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          {/* Logo con fondo anaranjado y cruz */}
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-orange-400 via-orange-500 to-orange-600 flex items-center justify-center font-black text-white shadow-md shadow-orange-500/30 border border-orange-400/40 select-none">
            <span className="text-xs font-black tracking-tight">GG</span>
            <span className="text-sm font-serif font-black ml-0.5 leading-none">✝</span>
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-black text-base text-white tracking-tight">
                GG <span className="text-orange-400 font-serif">✝</span>
              </span>
              <span className="text-orange-400 font-mono text-[9px] bg-orange-500/15 border border-orange-500/30 px-1.5 py-0.5 rounded font-bold">
                REELS
              </span>
            </div>
            <p className="text-[10px] text-zinc-400">Sabiduría en micro-lecciones</p>
          </div>
        </div>
      </div>

      {/* ========================================================
          CARD 1: RACHA ACTIVA (Real advancing streak)
          ======================================================== */}
      <div className="relative rounded-[28px] p-5 sm:p-6 bg-zinc-900/90 border border-amber-500/40 shadow-xl space-y-4 overflow-hidden">
        {/* Ambient Top-Right Glow */}
        <div className="absolute -top-12 -right-12 w-36 h-36 bg-amber-500/10 rounded-full blur-2xl pointer-events-none" />

        {/* Header row */}
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-amber-400 shrink-0 mt-0.5">
              <Flame className="w-5 h-5 fill-amber-400 text-amber-400" />
            </div>

            <div>
              <span className="text-[11px] font-black tracking-wider uppercase text-amber-400 block mb-0.5">
                RACHA ACTIVA
              </span>
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-xl sm:text-2xl font-black text-white">
                  {streakData.count} {streakData.count === 1 ? 'Día Seguido' : 'Días Seguidos'}
                </h2>
                <span className="px-2 py-0.5 rounded-full bg-amber-500/20 border border-amber-500/40 text-amber-300 text-[11px] font-bold flex items-center gap-1">
                  <Flame className="w-3 h-3 fill-amber-400 text-amber-400" /> {multiplier} XP
                </span>
              </div>
              <p className="text-xs text-zinc-400 mt-1 font-medium">
                {hasCheckedInToday
                  ? '¡Excelente! Check-in de hoy completado. Vuelve mañana para seguir aumentando tu racha.'
                  : 'Completa tu check-in diario para mantener encendida la llama del hábito.'}
              </p>
            </div>
          </div>

          {/* Check-in Button */}
          <button
            onClick={handleCheckIn}
            disabled={hasCheckedInToday}
            className={`px-3.5 sm:px-4 py-2 rounded-xl font-black text-xs transition-all flex items-center gap-1.5 shrink-0 shadow-md ${
              hasCheckedInToday
                ? 'bg-zinc-800 text-zinc-400 border border-zinc-700 cursor-default'
                : 'bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-zinc-950 shadow-amber-500/25 active:scale-95'
            }`}
          >
            <Zap className={`w-3.5 h-3.5 ${hasCheckedInToday ? 'text-zinc-500' : 'fill-current'}`} />
            <span>{hasCheckedInToday ? '¡Completado! ✓' : 'Check-in (+20 XP)'}</span>
          </button>
        </div>

        {/* 7-Day Real Streak Tracker */}
        <div className="grid grid-cols-7 gap-1.5 sm:gap-2.5 pt-1">
          {daysOfWeek.map((day, idx) => (
            <div
              key={idx}
              className={`rounded-2xl p-2 sm:p-2.5 flex flex-col items-center justify-center transition-all ${
                day.isToday
                  ? 'bg-amber-950/30 border-2 border-amber-500 shadow-md shadow-amber-500/20 scale-105'
                  : day.isChecked
                  ? 'bg-zinc-850/80 border border-zinc-700/60'
                  : 'bg-zinc-900/50 border border-zinc-800/60 opacity-60'
              }`}
            >
              <span className={`text-[11px] font-bold mb-1.5 ${day.isToday ? 'text-amber-300' : 'text-zinc-400'}`}>
                {day.label}
              </span>

              {day.isChecked ? (
                <>
                  <Flame className="w-4 h-4 fill-amber-400 text-amber-400 mb-1" />
                  <Check className="w-3 h-3 text-amber-400 font-bold" />
                </>
              ) : day.isToday ? (
                <>
                  <Flame className="w-4 h-4 text-amber-400/50 animate-pulse mb-1" />
                  <span className="text-[9px] text-amber-400 font-bold">Hoy</span>
                </>
              ) : (
                <>
                  <div className="w-4 h-4 rounded-full border border-zinc-600 flex items-center justify-center mb-1">
                    <span className="w-1 h-1 rounded-full bg-zinc-600" />
                  </div>
                  <span className="text-[10px] text-zinc-600 font-bold">-</span>
                </>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* ========================================================
          CARD 2: TIEMPO DE APRENDIZAJE (Daily Goal & Minutes)
          ======================================================== */}
      <div className="rounded-[28px] p-5 sm:p-6 bg-zinc-900/90 border border-zinc-800/80 shadow-xl space-y-4">
        {/* Header row */}
        <div className="flex items-start justify-between">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-emerald-400 shrink-0 mt-0.5">
              <Clock className="w-5 h-5 text-emerald-400" />
            </div>

            <div>
              <span className="text-[11px] font-black tracking-wider uppercase text-emerald-400 block mb-0.5">
                TIEMPO DE APRENDIZAJE
              </span>
              <h2 className="text-xl sm:text-2xl font-black text-white">
                {learnedMinutes} de {goalMinutes} Minutos Hoy
              </h2>
            </div>
          </div>

          <div className="text-right">
            <span className="text-2xl sm:text-3xl font-black text-emerald-400 block leading-none">
              {progressPercent}%
            </span>
            <span className="text-[11px] text-zinc-400 font-medium">
              de tu meta diaria
            </span>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="w-full h-2.5 rounded-full bg-zinc-800 overflow-hidden">
          <div
            className="h-full rounded-full bg-gradient-to-r from-emerald-500 to-teal-400 transition-all duration-500 shadow-[0_0_12px_rgba(16,185,129,0.5)]"
            style={{ width: `${progressPercent}%` }}
          />
        </div>

        {/* Sub-bar Sprint info */}
        <div className="flex items-center justify-between text-xs">
          <span className="text-zinc-400 font-medium">
            {remainingMinutes > 0 ? `Faltan ${remainingMinutes} min para tu meta` : '¡Meta diaria completada! 🎉'}
          </span>
          <button
            onClick={handleAddSprint}
            className="font-bold text-emerald-400 hover:text-emerald-300 transition-colors active:scale-95 cursor-pointer"
          >
            + 5 min sprint
          </button>
        </div>

        {/* Adjust Goal Pills */}
        <div className="flex items-center justify-between pt-1 border-t border-zinc-800/60">
          <span className="text-xs text-zinc-400 font-semibold">
            Ajustar meta:
          </span>
          <div className="flex items-center gap-2">
            {[15, 25, 45].map((mins) => {
              const isSelected = goalMinutes === mins;
              return (
                <button
                  key={mins}
                  onClick={() => {
                    soundManager.playPop();
                    setGoalMinutes(mins);
                  }}
                  className={`px-3.5 py-1 rounded-full text-xs font-bold transition-all ${
                    isSelected
                      ? 'bg-emerald-400 text-zinc-950 shadow-md shadow-emerald-500/25 scale-105'
                      : 'bg-zinc-800/90 text-zinc-400 hover:text-white'
                  }`}
                >
                  {mins}m
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* ========================================================
          CARD 3: MISIONES DEL DÍA (Daily Quests)
          ======================================================== */}
      <div className="rounded-[28px] p-5 sm:p-6 bg-zinc-900/90 border border-zinc-800/80 shadow-xl space-y-3.5">
        {/* Header row */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-500/15 border border-indigo-500/30 flex items-center justify-center text-indigo-400 shrink-0">
              <Target className="w-5 h-5 text-indigo-400" />
            </div>

            <div>
              <span className="text-[11px] font-black tracking-wider uppercase text-indigo-400 block mb-0.5">
                MISIONES DEL DÍA
              </span>
              <h2 className="text-xl sm:text-2xl font-black text-white">
                Metas Diarias ({claimedMissions.length}/4)
              </h2>
            </div>
          </div>

          <button
            onClick={handleClaimChest}
            className={`px-3.5 py-1.5 rounded-xl border text-xs font-bold transition-all flex items-center gap-1.5 active:scale-95 ${
              claimedChest
                ? 'bg-zinc-800 border-zinc-700 text-zinc-400'
                : 'bg-indigo-950/60 border-indigo-500/40 text-indigo-300 hover:bg-indigo-900/60 shadow-sm'
            }`}
          >
            <Gift className="w-3.5 h-3.5 text-indigo-400" />
            <span>{claimedChest ? 'Abierto ✓' : 'Cofre del Día'}</span>
          </button>
        </div>

        {/* 4 Quests List */}
        <div className="space-y-2.5 pt-1">
          {/* Mission 1 */}
          <div className="p-3.5 rounded-2xl bg-zinc-950/60 border border-zinc-800/90 flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center shrink-0 ${
                claimedMissions.includes('m1')
                  ? 'border-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.3)]'
                  : 'border-zinc-600'
              }`}>
                <div className={`w-2 h-2 rounded-full ${claimedMissions.includes('m1') ? 'bg-emerald-400' : 'bg-transparent'}`} />
              </div>

              <div>
                <div className="flex items-center gap-1.5 flex-wrap">
                  <h3 className="text-xs sm:text-sm font-bold text-white">
                    Ver 3 Reels Educativos
                  </h3>
                  <span className="text-[10px] font-extrabold text-amber-400 bg-amber-500/15 px-1.5 py-0.5 rounded">
                    +15 XP
                  </span>
                </div>
                <p className="text-[11px] text-zinc-400">
                  Desliza y aprende de 3 lecciones distintas
                </p>
              </div>
            </div>

            <button
              onClick={() => handleClaimMission('m1', 15)}
              disabled={claimedMissions.includes('m1')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-black transition-all flex items-center gap-1 shrink-0 ${
                claimedMissions.includes('m1')
                  ? 'bg-zinc-800 text-zinc-500 cursor-default'
                  : 'bg-amber-400 hover:bg-amber-300 text-zinc-950 shadow-md shadow-amber-500/20 active:scale-95 cursor-pointer'
              }`}
            >
              <Sparkles className="w-3 h-3 fill-current" />
              <span>{claimedMissions.includes('m1') ? 'Reclamado' : 'Reclamar'}</span>
            </button>
          </div>

          {/* Mission 2 */}
          <div className="p-3.5 rounded-2xl bg-zinc-950/60 border border-zinc-800/90 flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center shrink-0 ${
                claimedMissions.includes('m2')
                  ? 'border-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.3)]'
                  : 'border-zinc-600'
              }`}>
                <div className={`w-2 h-2 rounded-full ${claimedMissions.includes('m2') ? 'bg-emerald-400' : 'bg-transparent'}`} />
              </div>

              <div>
                <div className="flex items-center gap-1.5 flex-wrap">
                  <h3 className="text-xs sm:text-sm font-bold text-white">
                    Superar 1 Quiz de Conocimiento
                  </h3>
                  <span className="text-[10px] font-extrabold text-amber-400 bg-amber-500/15 px-1.5 py-0.5 rounded">
                    +20 XP
                  </span>
                </div>
                <p className="text-[11px] text-zinc-400">
                  Acierta la trivia financiera o de hábitos
                </p>
              </div>
            </div>

            <button
              onClick={() => handleClaimMission('m2', 20)}
              disabled={claimedMissions.includes('m2')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-black transition-all flex items-center gap-1 shrink-0 ${
                claimedMissions.includes('m2')
                  ? 'bg-zinc-800 text-zinc-500 cursor-default'
                  : 'bg-amber-400 hover:bg-amber-300 text-zinc-950 shadow-md shadow-amber-500/20 active:scale-95 cursor-pointer'
              }`}
            >
              <Sparkles className="w-3 h-3 fill-current" />
              <span>{claimedMissions.includes('m2') ? 'Reclamado' : 'Reclamar'}</span>
            </button>
          </div>

          {/* Mission 3 */}
          <div className="p-3.5 rounded-2xl bg-zinc-950/60 border border-zinc-800/90 flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center shrink-0 ${
                claimedMissions.includes('m3')
                  ? 'border-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.3)]'
                  : 'border-zinc-600'
              }`}>
                <div className={`w-2 h-2 rounded-full ${claimedMissions.includes('m3') ? 'bg-emerald-400' : 'bg-transparent'}`} />
              </div>

              <div>
                <div className="flex items-center gap-1.5 flex-wrap">
                  <h3 className="text-xs sm:text-sm font-bold text-white">
                    Escuchar con Narrador de Voz
                  </h3>
                  <span className="text-[10px] font-extrabold text-amber-400 bg-amber-500/15 px-1.5 py-0.5 rounded">
                    +15 XP
                  </span>
                </div>
                <p className="text-[11px] text-zinc-400">
                  Activa la voz en off para aprendizaje auditivo
                </p>
              </div>
            </div>

            <button
              onClick={() => handleClaimMission('m3', 15)}
              disabled={claimedMissions.includes('m3')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-black transition-all flex items-center gap-1 shrink-0 ${
                claimedMissions.includes('m3')
                  ? 'bg-zinc-800 text-zinc-500 cursor-default'
                  : 'bg-amber-400 hover:bg-amber-300 text-zinc-950 shadow-md shadow-amber-500/20 active:scale-95 cursor-pointer'
              }`}
            >
              <Sparkles className="w-3 h-3 fill-current" />
              <span>{claimedMissions.includes('m3') ? 'Reclamado' : 'Reclamar'}</span>
            </button>
          </div>

          {/* Mission 4 (Pending) */}
          <div className="p-3.5 rounded-2xl bg-zinc-950/60 border border-zinc-800/90 flex items-center justify-between gap-3 opacity-80">
            <div className="flex items-center gap-3">
              <div className="w-6 h-6 rounded-full border-2 border-zinc-700 flex items-center justify-center shrink-0">
                <div className="w-1.5 h-1.5 rounded-full bg-zinc-700" />
              </div>

              <div>
                <div className="flex items-center gap-1.5 flex-wrap">
                  <h3 className="text-xs sm:text-sm font-bold text-white">
                    Consultar al Mentor IA
                  </h3>
                  <span className="text-[10px] font-extrabold text-amber-400 bg-amber-500/15 px-1.5 py-0.5 rounded">
                    +15 XP
                  </span>
                </div>
                <p className="text-[11px] text-zinc-500">
                  Toca el botón IA en un Reel para profundizar
                </p>
              </div>
            </div>

            <span className="text-xs font-bold text-zinc-500 px-3">
              0/1
            </span>
          </div>
        </div>
      </div>

      {/* ========================================================
          QUICK ACCESS BUTTONS (Biblioteca y Subir Archivo)
          ======================================================== */}
      <div className="grid grid-cols-2 gap-3 pt-2">
        <button
          onClick={() => {
            soundManager.playPop();
            onOpenLibrary();
          }}
          className="p-3.5 rounded-2xl bg-zinc-900/90 hover:bg-zinc-850 border border-zinc-800 hover:border-amber-500/40 text-left transition-all group flex items-center justify-between cursor-pointer"
        >
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-amber-500/10 text-amber-400 group-hover:bg-amber-500/20">
              <BookOpen className="w-4 h-4" />
            </div>
            <div>
              <p className="text-xs font-bold text-zinc-200">Biblioteca</p>
              <p className="text-[10px] text-zinc-500">{collections.length} Libros</p>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-zinc-600 group-hover:text-amber-400 transition-colors" />
        </button>

        <button
          onClick={() => {
            soundManager.playPop();
            onOpenUpload();
          }}
          className="p-3.5 rounded-2xl bg-zinc-900/90 hover:bg-zinc-850 border border-zinc-800 hover:border-amber-500/40 text-left transition-all group flex items-center justify-between cursor-pointer"
        >
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-amber-500/10 text-amber-400 group-hover:bg-amber-500/20">
              <PlusCircle className="w-4 h-4" />
            </div>
            <div>
              <p className="text-xs font-bold text-zinc-200">Subir Archivo</p>
              <p className="text-[10px] text-zinc-500">Crear reels</p>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-zinc-600 group-hover:text-amber-400 transition-colors" />
        </button>
      </div>
    </div>
  );
};
